$(function() {
	$('#annotation_category_hex').colorPicker();
});
